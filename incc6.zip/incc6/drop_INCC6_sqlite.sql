
DROP TABLE [collar_data_entry];
GO
DROP TABLE [test_parms_rec];
GO
DROP TABLE [stratum_ids];
GO
DROP TABLE [sr_parms_rec];
GO
DROP TABLE [notification_log];
GO
DROP TABLE [mbas];
GO
DROP TABLE [LMINCCAppContext];
GO
DROP TABLE [items];
GO
DROP TABLE [item_isotopics];
GO
DROP TABLE [isotopics_source_code];
GO
DROP TABLE [isotopics];
GO
DROP TABLE [io_code];
GO
DROP TABLE [inventory_change_code];
GO
DROP TABLE [facility_names];
GO
DROP TABLE [error_codes];
GO
DROP TABLE [unattended_parms_rec];
GO
DROP TABLE [truncated_mult_rec];
GO
DROP TABLE [tm_bkg_parms_rec];
GO
DROP TABLE [stratum_id_instances];
GO
DROP TABLE [stratum_id_detector];
GO
DROP TABLE [sr_parms_ext];
GO
DROP TABLE [norm_parms_rec];
GO
DROP TABLE [multiplicity_rec];
GO
DROP TABLE [multiplicity_rec_m];
GO
DROP TABLE [known_alpha_rec_m];
GO
DROP TABLE [known_m_rec_m];
GO
DROP TABLE [cm_pu_ratio_rec_m];
GO
DROP TABLE [curium_ratio_rec_m];
GO
DROP TABLE [cal_curve_rec_m];
GO
DROP TABLE [add_a_source_rec_m];
GO
DROP TABLE [active_rec_m];
GO
DROP TABLE [truncated_mult_rec_m];
GO
DROP TABLE [active_passive_rec_m];
GO
DROP TABLE [active_rec];
GO
DROP TABLE [active_mult_rec_m];
GO
DROP TABLE [collar_rec_m];
GO
DROP TABLE [collar_detector_rec_m];
GO
DROP TABLE [collar_k5_rec_m];
GO
DROP TABLE [de_mult_rec_m];
GO
DROP TABLE [results_truncated_mult_rec];
GO
DROP TABLE [results_rec];
GO
DROP TABLE [results_multiplicity_rec];
GO
DROP TABLE [results_known_alpha_rec];
GO
DROP TABLE [results_curium_ratio_rec];
GO
DROP TABLE [results_cal_curve_rec];
GO
DROP TABLE [results_add_a_source_rec];
GO
DROP TABLE [results_active_rec];
GO
DROP TABLE [results_active_passive_rec];
GO
DROP TABLE [results_active_mult_rec];
GO
DROP TABLE [results_known_m_rec];
GO
DROP TABLE [results_collar_rec];
GO
DROP TABLE [results_bias_rec];
GO
DROP TABLE [results_de_mult_rec];
GO
DROP TABLE [results_init_src_rec];
GO
DROP TABLE [results_precision_rec];
GO
DROP TABLE [results_tm_bkg_rec];
GO
DROP TABLE [LMNetComm];
GO
DROP TABLE [LMMultiplicity];
GO
DROP TABLE [LMHWParams];
GO
DROP TABLE [LMAcquireParams];
GO
DROP TABLE [known_m_rec];
GO
DROP TABLE [known_alpha_rec];
GO
DROP TABLE [detector_types];
GO
DROP TABLE [de_mult_rec];
GO
DROP TABLE [cycleslm];
GO
DROP TABLE [cycles];
GO
DROP TABLE [curium_ratio_rec];
GO
DROP TABLE [CountingParams];
GO
DROP TABLE [composite_isotopic_rec]
GO
DROP TABLE [composite_isotopics_rec];
GO
DROP TABLE [collar_rec];
GO
DROP TABLE [collar_k5_rec];
GO
DROP TABLE [collar_detector_rec];
GO
DROP TABLE [cm_pu_ratio_rec];
GO
DROP TABLE [cal_curve_rec];
GO
DROP TABLE [bkg_parms_rec];
GO
DROP TABLE [analysis_method_rec];
GO
DROP TABLE [alpha_beta_rec];
GO
DROP TABLE [add_a_source_setup_rec];
GO
DROP TABLE [add_a_source_rec];
GO
DROP TABLE [active_passive_rec];
GO
DROP TABLE [active_mult_rec];
GO
DROP TABLE [acquire_parms_rec];
GO
DROP TABLE [material_types];
GO
DROP TABLE [holdup_config_rec];
GO
DROP TABLE [poison_rod_type_rec];
GO
DROP TABLE [HVStatus];
GO
DROP TABLE [HVResult];
GO
DROP TABLE [HVCalibrationParams];
GO
DROP TABLE [analysis_messages];
GO
DROP TABLE [results_filenames];
GO
DROP TABLE [measurements];
GO
DROP TABLE [detectors];
GO
